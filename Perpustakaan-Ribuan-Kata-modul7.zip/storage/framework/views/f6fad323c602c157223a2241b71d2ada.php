

<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>

    <section class="relative w-full">
        <img src="<?php echo e(asset('images/perpus.jpeg')); ?>" alt="Perpustakaan Ribuan Kata" class="h-[600px] w-full object-cover">

        <div class="absolute inset-0 flex flex-col items-center justify-center bg-black/30 px-4 text-center">
            <h1 class="text-4xl font-bold tracking-wide text-white sm:text-5xl md:text-7xl">
                SELAMAT DATANG
            </h1>

            <p class="mt-4 text-lg font-bold text-white sm:text-2xl md:text-3xl">
                DI PERPUSTAKAAN - RIBUAN KATA
            </p>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.perpus', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\modul6_praktikum\mdl6_perpustakaan_250441100077\resources\views/home.blade.php ENDPATH**/ ?>