

<?php $__env->startSection('title', 'Riwayat Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mx-auto max-w-7xl px-4 py-8">

        
        <div class="mb-8">
            <h1 class="text-2xl font-bold text-gray-800">
                Riwayat Peminjaman
            </h1>
            <p class="mt-1 text-sm text-gray-500">
                Lihat daftar buku yang pernah kamu pinjam di perpustakaan.
            </p>
        </div>

        
        <div class="overflow-hidden rounded-xl border border-gray-100 bg-white shadow-sm">

            <div class="border-b border-gray-100 px-6 py-5">
                <h2 class="text-lg font-semibold text-gray-800">
                    Daftar Riwayat Buku
                </h2>
                <p class="mt-1 text-sm text-gray-500">
                    Informasi peminjaman dan pengembalian buku.
                </p>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm">

                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-6 py-4">No.</th>
                            <th class="px-6 py-4">Judul Buku</th>
                            <th class="px-6 py-4">Tanggal Pinjam</th>
                            <th class="px-6 py-4">Tanggal Kembali</th>
                            <th class="px-6 py-4">Status</th>
                            <th class="px-6 py-4">Aksi</th>
                        </tr>
                    </thead>

                    <tbody class="divide-y divide-gray-100 text-gray-700">

                        <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peminjaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="transition hover:bg-gray-50">

                                <td class="px-6 py-4">
                                    <?php echo e($index + 1); ?>

                                </td>

                                <td class="px-6 py-4 font-medium">
                                    <?php echo e($peminjaman->buku->judul); ?>

                                </td>

                                <td class="px-6 py-4">
                                    <?php echo e($peminjaman->tanggal_pinjam->format('d-m-Y')); ?>

                                </td>

                                <td class="px-6 py-4">
                                    <?php echo e($peminjaman->tanggal_kembali ? $peminjaman->tanggal_kembali->format('d-m-Y') : '-'); ?>

                                </td>

                                <td class="px-6 py-4">
                                    <?php if($peminjaman->tanggal_kembali): ?>
                                        <span
                                            class="rounded-full bg-green-100 px-3 py-1 text-xs font-medium text-green-700">
                                            Dikembalikan
                                        </span>
                                    <?php else: ?>
                                        <span
                                            class="rounded-full bg-amber-100 px-3 py-1 text-xs font-medium text-amber-700">
                                            Dipinjam
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4">
                                    <a href="<?php echo e(route('peminjaman.show', $peminjaman->id)); ?>"
                                        class="inline-block rounded-lg px-4 py-2 text-xs font-semibold text-white transition hover:opacity-90"
                                        style="background-color: #a82a2a;">
                                        Detail
                                    </a>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-10 text-center text-gray-500">
                                    Kamu belum memiliki riwayat peminjaman buku.
                                </td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.perpus', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\modul6_praktikum\mdl6_perpustakaan_250441100077\resources\views/peminjaman/riwayat.blade.php ENDPATH**/ ?>