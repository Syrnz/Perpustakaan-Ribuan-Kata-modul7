

<?php $__env->startSection('title', 'Dashboard Petugas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <h1 class="text-2xl font-bold text-gray-800">
            Dashboard Petugas
        </h1>

        <p class="mt-2 text-gray-600">
            Selamat datang, <?php echo e(auth()->user()->name); ?>!
        </p>

        <p class="mt-4">
            Anda login sebagai Petugas Perpustakaan.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.perpus', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\modul6_praktikum\mdl6_perpustakaan_250441100077\resources\views/dashboard/petugas.blade.php ENDPATH**/ ?>