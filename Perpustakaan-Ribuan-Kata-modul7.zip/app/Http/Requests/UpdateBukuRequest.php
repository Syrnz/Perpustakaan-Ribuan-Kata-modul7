<?php

namespace App\Http\Requests;

// use Illuminate\Contracts\Validation\ValidationRule;
// use Illuminate\Foundation\Http\FormRequest;
use App\Http\Requests\StoreBukuRequest;

class UpdateBukuRequest extends StoreBukuRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return True;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $rules = parent::rules();

        foreach ($rules as $field => $fieldRules) {
            $fieldRules = is_array($fieldRules)
                ? $fieldRules
                : explode('|', $fieldRules);

            $fieldRules = array_map(
                fn($rule) => $rule === 'required' ? 'sometimes' : $rule,
                $fieldRules
            );

            $rules[$field] = $fieldRules;
        }

        return $rules;
    }
}
